=== Knižnica Mamateyka ===
Contributors: mikulaspolak
Tags: library, books, catalog, reservation
Requires at least: 5.9
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.93.0
License: Proprietary - All rights reserved

Správa malej knižnice - verejný katalóg kníh s vyhľadávaním a filtrovaním, rezervácie kníh na email
a mobilne prívetivé editor rozhranie pre knihovníčky.

Kategórie sa spravujú priamo názvom. Knihy používajú názvy kategórií aj v JSON importe/exporte;
interné databázové ID kategórií nie je súčasťou používateľského formátu.
Jazyk knihy je v JSON exporte uložený priamo v položke knihy ako text. Import funguje ako
merge/upsert: položky zo súboru pridá alebo aktualizuje a lokálne položky, ktoré v súbore chýbajú,
nevymaže. Staršie exporty so samostatným poľom `languages` sú spätne kompatibilné a toto pole
sa ignoruje.

== Popis ==

* `[kniznica_katalog]` - verejný zoznam kníh s vyhľadávaním/filtrovaním a rezervačným formulárom.
  Ak je návštevník prihlásený ako knihovníčka, v rovnakom rozhraní pribudnú tlačidlá na správu kníh
  a rezervácií.
* `[kniznica_prihlasenie]` - prihlasovací formulár pre knihovníčky (interne používa štandardné
  WP prihlásenie).
* WP Admin -> Knižnica: nastavenia (email na rezervácie, texty, branding, limity), správa účtov
  knihovníčok a Import/Export dát v JSON formáte.

== Filtrovanie katalógu ==

Viac vybraných hodnôt v jednom filtri sa kombinuje ako OR, zatiaľ čo rôzne filtre sa
kombinujú ako AND.

Kniha má naďalej uložený iba jeden jazyk a jeden rok. Viacvýber sa týka iba filtrovania.
REST endpoint katalógu prijíma viac hodnôt vo formáte oddelenom čiarkami, napríklad
`year=2024,2023`.

== Inštalácia ==

1. Nahrajte zip súbor pluginu cez Pluginy -> Pridať nový -> Nahrať plugin.
2. Aktivujte plugin.
3. Vo WP Admin -> Knižnica -> Nastavenia nastavte emailovú adresu pre rezervácie.
4. Vo WP Admin -> Knižnica -> Knihovníčky vytvorte účty pre kolegyne.
5. Vo WP Admin -> Knižnica -> Import/Export naimportujte existujúci zoznam kníh (JSON).
6. Vložte shortcode `[kniznica_katalog]` na stránku knižnice a `[kniznica_prihlasenie]` na
   prihlasovaciu stránku.

== Účty knihovníčok ==

Knihovníčky pracujú vo frontendovom editor rozhraní a nemajú prístup do WordPress administrácie.
Administrátor vytvára účet iba s jedným menom; toto meno sa používa aj pri prihlasovaní.
V časti WP Admin -> Knižnica -> Knihovníčky môže prístup deaktivovať alebo obnoviť.
Deaktivácia neruší WordPress účet ani históriu; trvalé odstránenie účtu je samostatná operácia.
Deaktivácia pluginu sama osebe účty ani rolu nemaže.
