=== Breakdance Slovak UI ===
Contributors: mikulaspolak
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: Proprietary - All rights reserved

Test Slovak translation of 10 Breakdance editor texts.

== Description ==

Adds Slovak translations for these Breakdance editor texts:
Add, Back, Cancel, Close, Copy, Delete, Duplicate, Edit, Preview, Save.

- Uses the existing `breakdance_i18n_json` filter of Breakdance; no Breakdance files are modified.
- Translations apply only to users whose profile language is Slovencina (sk_SK). Other users see no change.
- Translations already present in Breakdance are never overwritten.
- No settings page: activate the plugin to enable the translation, deactivate it to restore the original texts.
- Covers only JavaScript texts of the Breakdance editor. PHP texts, WordPress admin and site content are not translated.

Tested with Breakdance 2.8.3. The filter is not documented as public API, so re-test after Breakdance updates.

== Installation ==

1. Upload the folder `breakdance-slovak-ui` to `wp-content/plugins/` (or install the ZIP).
2. Activate the plugin in WP Admin -> Plugins.
3. In Users -> Profile set Language to Slovencina.
4. Open the Breakdance editor.

== Release build ==

Run `build-release.ps1` from the parent project folder. The first release uses the version currently in the plugin; every following release increments the minor version. The script updates version metadata and this changelog, then creates and validates a ZIP under `Releases/` with `breakdance-slovak-ui` as its root folder.

== Changelog ==

= 1.0.0 =
- initial test release with 10 translated editor texts
