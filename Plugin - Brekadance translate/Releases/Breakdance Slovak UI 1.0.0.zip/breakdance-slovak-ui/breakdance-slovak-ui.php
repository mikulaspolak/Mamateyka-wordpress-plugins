<?php

/**
 * Plugin Name: Breakdance Slovak UI
 * Description: Test Slovak translation of 10 Breakdance editor texts. Active only for users whose language is Slovencina (sk_SK).
 * Version: 1.0.0
 * Author: Mikulas Polak
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: Proprietary - All rights reserved
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BSU_PLUGIN_VERSION', '1.0.0');
define('BSU_PLUGIN_PATH', plugin_dir_path(__FILE__));

const BSU_LOCALE = 'sk_SK';
const BSU_DOMAIN = 'breakdance';

function bsu_load_translations()
{
    $path = BSU_PLUGIN_PATH . 'languages/breakdance-' . BSU_LOCALE . '.json';
    if (!is_readable($path)) {
        return null;
    }

    $data = json_decode((string) file_get_contents($path), true);
    $messages = $data['locale_data'][BSU_DOMAIN] ?? null;

    return is_array($messages) ? $messages : null;
}

/**
 * Adds translations to the locale data Breakdance prints into its editor.
 * Any failure returns the original JSON so the editor keeps working.
 *
 * @param mixed       $json   JSON string from the breakdance_i18n_json filter ('{}' when Breakdance has no file for the locale).
 * @param string|null $locale Locale override, used for testing.
 * @return mixed
 */
function bsu_filter_i18n_json($json, $locale = null)
{
    if (!is_string($json)) {
        return $json;
    }

    if ($locale === null) {
        $locale = get_user_locale();
    }
    if ($locale !== BSU_LOCALE) {
        return $json;
    }

    $ours = bsu_load_translations();
    if ($ours === null) {
        return $json;
    }

    $data = json_decode($json, true);
    if (!is_array($data)) {
        return $json;
    }

    $existing = $data['locale_data'][BSU_DOMAIN] ?? [];
    if (!is_array($existing)) {
        return $json;
    }

    // Breakdance sets localeData[""].domain, so the metadata key must exist.
    $merged = $existing + $ours;
    if (!isset($merged['']) || !is_array($merged[''])) {
        $merged[''] = $ours[''] ?? [];
    }

    $data['domain'] = $data['domain'] ?? BSU_DOMAIN;
    $data['locale_data'][BSU_DOMAIN] = $merged;

    $encoded = wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP);

    return is_string($encoded) ? $encoded : $json;
}
add_filter('breakdance_i18n_json', 'bsu_filter_i18n_json', 20);
