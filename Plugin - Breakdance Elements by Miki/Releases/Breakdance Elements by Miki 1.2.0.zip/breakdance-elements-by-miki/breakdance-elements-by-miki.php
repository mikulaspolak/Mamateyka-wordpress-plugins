<?php

/**
 * Plugin Name: Breakdance Elements by Miki
 * Description: Custom Breakdance elements, macros, and presets by Miki.
 * Version: 1.2.0
 * Author: Mikulas Polak
 * Requires at least: 6.0
 * Requires PHP: 8.2
 * License: Proprietary - All rights reserved
 */

namespace BreakdanceElementsByMiki;

if (!defined('ABSPATH')) {
    exit;
}

use function Breakdance\Util\getDirectoryPathRelativeToPluginFolder;

const CATEGORY_SLUG = 'miki-elements';
const CATEGORY_LABEL = 'Elements by Miki';

function is_breakdance_available(): bool
{
    return function_exists('Breakdance\Elements\registerCategory')
        && function_exists('Breakdance\ElementStudio\registerSaveLocation')
        && function_exists('Breakdance\Util\getDirectoryPathRelativeToPluginFolder');
}

// Priority 9 runs before Breakdance includes the element files, so the category exists when elements load.
add_action('breakdance_loaded', function () {
    if (!is_breakdance_available()) {
        return;
    }

    \Breakdance\Elements\registerCategory(CATEGORY_SLUG, CATEGORY_LABEL);

    $pluginPath = getDirectoryPathRelativeToPluginFolder(__DIR__);

    \Breakdance\ElementStudio\registerSaveLocation(
        $pluginPath . '/elements',
        'BreakdanceElementsByMiki',
        'element',
        'Miki Elements',
        false
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        $pluginPath . '/macros',
        'BreakdanceElementsByMiki',
        'macro',
        'Miki Macros',
        false
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        $pluginPath . '/presets',
        'BreakdanceElementsByMiki',
        'preset',
        'Miki Presets',
        false
    );
}, 9);

add_action('admin_notices', function () {
    if (is_breakdance_available() || !current_user_can('activate_plugins')) {
        return;
    }

    echo '<div class="notice notice-warning"><p>'
        . esc_html__('Breakdance Elements by Miki vyžaduje aktívny plugin Breakdance.', 'breakdance-elements-by-miki')
        . '</p></div>';
});
