(function () {
  const mobileQuery = window.matchMedia('(max-width: 767px)');

  function setExpanded(card, expanded) {
    const button = card.querySelector('.miki-memories__toggle');
    const body = card.querySelector('.miki-memories__body');

    card.classList.toggle('miki-memories__card--expanded', expanded);

    if (button) {
      button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    }

    if (body) {
      if (mobileQuery.matches) {
        body.setAttribute('aria-hidden', expanded ? 'false' : 'true');
        body.inert = !expanded;
      } else {
        body.removeAttribute('aria-hidden');
        body.inert = false;
      }
    }
  }

  function syncResponsiveState() {
    document.querySelectorAll('[data-miki-memories]').forEach((grid) => {
      grid.querySelectorAll('[data-miki-memory-card]').forEach((card) => {
        setExpanded(card, false);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncResponsiveState, { once: true });
  } else {
    syncResponsiveState();
  }

  window.addEventListener('pageshow', syncResponsiveState);
  if (typeof mobileQuery.addEventListener === 'function') {
    mobileQuery.addEventListener('change', syncResponsiveState);
  } else {
    mobileQuery.addListener(syncResponsiveState);
  }

  document.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target : event.target.parentElement;
    const button = target?.closest('.miki-memories__toggle');

    if (!button || !mobileQuery.matches) {
      return;
    }

    const grid = button.closest('[data-miki-memories]');
    const card = button.closest('[data-miki-memory-card]');

    if (!grid || !card) {
      return;
    }

    grid.querySelectorAll('.miki-memories__card--expanded').forEach((expandedCard) => {
      if (expandedCard !== card) {
        setExpanded(expandedCard, false);
      }
    });

    setExpanded(card, true);

    const heading = card.querySelector('.miki-memories__heading');

    if (heading) {
      heading.focus({ preventScroll: true });
    } else {
      card.setAttribute('tabindex', '-1');
      card.focus({ preventScroll: true });
    }

    requestAnimationFrame(() => {
      const scrollTarget = heading || card;
      const bounds = scrollTarget.getBoundingClientRect();

      if (bounds.top < 0 || bounds.bottom > window.innerHeight) {
        scrollTarget.scrollIntoView({
          behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
          block: 'nearest',
        });
      }
    });
  });
})();
