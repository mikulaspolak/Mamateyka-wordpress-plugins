=== Breakdance Elements by Miki ===
Contributors: mikulaspolak
Requires at least: 6.0
Requires PHP: 8.2
Stable tag: 1.35.0
License: Proprietary - All rights reserved

Vlastné Breakdance prvky vytvorené v Breakdance Element Studio alebo ručne. Všetky sa v paneli pridávania prvkov zobrazujú v samostatnej sekcii **Elements by Miki**.

== Inštalácia ==

1. Vo WordPresse otvor Pluginy -> Pridať nový plugin -> Nahrať plugin.
2. Nahraj ZIP vytvorený skriptom build-release.ps1 a plugin aktivuj (vyžaduje aktívny Breakdance).
3. Otvor stránku v Breakdance, obnov editor a v paneli pridávania prvkov nájdi sekciu Elements by Miki.
4. Nové elementy cez Element Studio: New element -> umiestnenie Miki Elements. Nevyberaj priečinok Breakdance, pretože aktualizácia Breakdance môže jeho súbory prepísať.

== Element: Memories (Spomienky) ==

Mriežka kariet so spomienkami (nadpis sekcie a odkaz „Ďalšie spomienky“ si pridaj zvlášť ako bežné prvky Breakdance).

- Repeater kariet: obrázok (+ voliteľný alt), avatar autora, autor, nadpis, farebný štítok, voliteľný citát a text.
- Bez avatara sa zobrazí kruh s iniciálou autora. Bez obrázka sa obrázkový blok nezobrazí.
- Alt obrázka: vlastný alt z karty, inak alt z knižnice médií, inak prázdny (dekoratívny obrázok).
- Najviac 99 kariet; Breakdance neponúka UI limit pre repeater, preto je v editore upozornenie a limit vynucuje šablóna.
- Masonry cez CSS columns, poradie pokračuje zhora nadol v stĺpcoch. Režim stĺpcov: automatický (minimálna šírka karty) alebo manuálny (počet stĺpcov); obe hodnoty sú responzívne podľa breakpointov Breakdance.
- Dizajn: pozadie, farby, zaoblenie, počet riadkov textu; prepínače pre náklon kariet, lepiacu pásku a jemný hover (bez JavaScriptu, rešpektuje `prefers-reduced-motion`).

== Element: Featured Image (Ilustračný obrázok) ==

Zobrazí náhľadový obrázok (featured image) aktuálneho príspevku. Určený do šablóny článku; v šablóne stačí element vložiť, obrázok nastavuješ v príspevku.

- Obrázok sa dosadí na fronte PHP výstupným filtrom (`elements/Featured_Image_Ilustracny_obrazok/featured-image.php`, načítaný z hlavného súboru pluginu) len na jednotlivých príspevkoch/stránkach (`is_singular()`). Šablóna elementu vypisuje len značku `<!--miki-featured-image:...-->`, ktorú filter nahradí `<img>`. Element preto ukazuje obrázok aktuálnej stránky, nie položky v slučke (Loop).
- Predvolená veľkosť súboru je Full size (plné rozlíšenie, `srcset` ponúka aj menšie veľkosti); v nastaveniach sa dá zmeniť na Extra large / Large.
- V editore Breakdance sa náhľad načíta skriptom `featured-image-editor.js` (len pre prihlásených s `edit_posts`) cez AJAX `miki_featured_image_preview`: obrázok príspevku, ktorý canvas práve zobrazuje (pri úprave šablóny článku je to zvolený náhľadový príspevok; ID dodá PHP cez `get_queried_object_id()`), inak najnovší príspevok s náhľadovým obrázkom. Ak sa nenájde žiadny, zostane zástupný rámik.
- Bez náhľadového obrázka sa na fronte nezobrazí nič (ani rámik). V editore sa namiesto obrázka zobrazí zástupný rámik s vybraným vizuálom.
- Vizuál (Design -> Visual): Žiadny, 1, 2, 3. Fotka je orezaná SVG maskou (`mask`) s takmer obdĺžnikovým tvarom, jemne šikmými hranami a nerovnakými rohmi; tieň je `drop-shadow`. Za fotkou je vždy jeden oblý tvar s pevnou farbou `#CDDFE7`, ktorý ide diagonálne cez celé pozadie a vykukuje len v dvoch protiľahlých rohoch. Hodnoty `none`, `v1`..`v3` sú uložené v obsahu stránok, nemeň ich; neznáma uložená hodnota (napr. staré `v4`/`v5`) sa zobrazí ako Vizuál 1.
- Tvar sa prispôsobí pomeru strán obrázka (maska aj tvary v pozadí sa škálujú cez `cqw`, bez JavaScriptu). Extrémne pomery mimo 9:16 až 21:9 sa orežú.
- Orezanie (Design -> Image crop): pomer strán (Pôvodný, 1:1, 4:3, 3:2, 16:9, 21:9, 2:1, 3:4, 2:3, 9:16, Vlastný), prispôsobenie (Cover / Contain / Fill; responzívne) a vodorovná a zvislá poloha orezu v % (responzívne). Ovládače sa zobrazia, ak pomer nie je Pôvodný. Mení sa len CSS vlastnosť `aspect-ratio`, `object-fit` a `object-position` na `<img>`; automatické orezanie extrémnych pomerov (`--fi-auto-ratio`) platí len pri pomere Pôvodný.
- Nastavenia: maximálna šírka, zarovnanie (responzívne), veľkosť súboru obrázka, odsadenie, zaoblenie (len pri vizuáli Žiadny), tieň, animácia pri načítaní (rešpektuje `prefers-reduced-motion`).
- Obrázok sa načítava `eager` s `fetchpriority="high"` (ilustrácia je zvyčajne v hornej časti článku).

== Element: Google Calendar (Google kalendár) ==

Vložený verejný Google kalendár (iframe) s rovnakým vzhľadom ako pôvodný skript z webu.

- Obsah: ID kalendára a názov iframe (pre čítačky obrazovky). Kalendár musí byť verejný.
- Dizajn: výška (responzívna, predvolene 600 px), akcentová farba kalendára (len `#RRGGBB`, inak sa použije `#537891`) a farba pozadia.
- Iframe sa načíta len na obrazovkách od 1024 px (`elements/Google_Calendar_Google_kalendar/google-calendar.js`); v editore sa načíta vždy.
- Nadpis sekcie a odkaz na celý kalendár si pridaj zvlášť ako bežné prvky Breakdance.

== Element: Google Upcoming Events (Google najbližšie udalosti) ==

Zoznam najbližších udalostí z verejného Google kalendára (dátum, názov, deň a čas).

- Obsah: ID kalendára, Google API kľúč, počet udalostí na desktope (od 1024 px, predvolene 6) a na tablete/mobile (predvolene 4), texty pre prázdny zoznam, chybu a udalosť bez názvu.
- API kľúč nie je súčasťou pluginu; vkladá sa v editore a je viditeľný v zdrojovom kóde stránky. V Google Cloud Console ho obmedz na Google Calendar API a referrer webu (napr. `mamateyka.sk/*`).
- Udalosti sa načítajú v prehliadači (`google-upcoming-events.js`) cez Google Calendar API; názvy sa vkladajú ako text (nie HTML). Časy sa zobrazujú v časovej zóne Europe/Bratislava.
- Dizajn: farby pozadia a textu dátumu, vedľajšieho textu a oddeľovacej čiary.

== Element: Toast (Oznámenie) ==

Plávajúce oznámenie v hornej časti stránky (nahrádza skript z priečinka Script - Toast). Vlož ho na stránku alebo do šablóny; predvolené nastavenia zodpovedajú pôvodnému oznámeniu „Mamateyka 30 rokov“.

- Obsah: ikona (znak), nadpis, text, tlačidlo (text, odkaz, nová karta) a popis tlačidla zavrieť. Ikonu aj tlačidlo možno vypnúť; tlačidlo sa nezobrazí bez textu alebo odkazu.
- Správanie: zatvorenie tlačidlom × alebo potiahnutím do strany (swipe). Voliteľne sa po zatvorení alebo kliknutí na tlačidlo oznámenie v tej istej relácii prehliadača (`sessionStorage`) už nezobrazí; kľúč je „ID oznámenia“ (predvolene `top-toast-seen`), pre každé oznámenie nastav iné.
- Dizajn: vzdialenosť od hora (desktop a mobil do 600 px), maximálna šírka, z-index, zaoblenie, tieň, veľkosť nadpisu a textu, farby (pozadie, text, akcent, hover tlačidla, znak ikony, text tlačidla, tlačidlo zavrieť).
- Skript `elements/Toast_Oznamenie/toast.js` je rovnaký pre všetky inštancie. V editore sa oznámenie zobrazuje ako bežný blok (nie ako plávajúce), aby sa dalo vybrať a upravovať; animácia rešpektuje `prefers-reduced-motion`.
- Odkaz tlačidla je obyčajné textové pole (bez výberu stránky z Breakdance).

== Aktualizácie Breakdance a WordPressu ==

- Plugin je samostatný priečinok `wp-content/plugins/breakdance-elements-by-miki/`. Aktualizácia Breakdance ani WordPressu ho neprepíše; prepísal by ho len Breakdance priečinok, preto elementy nikdy neukladaj do umiestnenia Breakdance.
- Obsah stránok je uložený v databáze. Ukladá sa slug elementu (`BreakdanceElementsByMiki\MemoriesSpomienky`) a cesty polí (napr. `content.memories.items[].heading`). **Tieto slugy ani cesty nikdy nemeň ani nepremenúvaj**, inak stránky stratia obsah. Názov v paneli, texty polí a CSS sa meniť môžu. Nové polia pridávaj len ako nepovinné s bezpečnou predvolenou hodnotou.
- Ak plugin deaktivuješ alebo zmažeš, elementy na stránkach sa zobrazia ako chýbajúce (dáta v databáze ostanú a po opätovnej aktivácii sa vrátia).
- Po nahratí novej verzie ZIPu vyprázdni/regeneruj cache CSS v nastaveniach Breakdance (presný názov možnosti over v 2.8.3) a cache stránky/CDN, aby sa načítal nový CSS elementu.
- Zdrojom pravdy je repozitár. ZIP prepíše celý priečinok pluginu, preto zmeny z Element Studio na serveri najprv stiahni do repozitára, inak sa stratia.
- Po väčšej aktualizácii Breakdance (nová hlavná verzia) plugin zobrazí upozornenie; skontroluj elementy v editore a na fronte. Plugin používa len stabilné časti API (`Element`, `c()`, `registerCategory`, `registerSaveLocation`) a pri chýbajúcom Breakdance sa nenačíta.
- Pred aktualizáciou Breakdance urob zálohu databázy a súborov.

== Preklady ==

Texty v editore sú v kóde po anglicky cez `t('...')`. Slovenčina (podľa jazyka používateľa v editore) je v `languages/sk_SK.php`. Kľúč musí byť presne rovnaký ako anglický text. Názov elementu: Memories (sk: Spomienky).

== Pridanie ďalšieho elementu ==

Každý element je samostatný priečinok `elements/<Názov>/` (`element.php`, `html.twig`, `css.twig`, `default.css`) a nesmie závisieť od iných elementov. Breakdance ho načíta automaticky, nič sa neregistruje centrálne. Použi kostru z `Templates/Element Skeleton/` (nie je súčasťou ZIPu), nastav `category()` na `miki-elements`, vlastný CSS prefix `miki-<názov>__` a unikátnu triedu/slug. Pred zmenami v Element Studio urob commit alebo zálohu; tlačidlo Delete v Studiu súbory odstráni.

== Vývoj a vydanie ==

Breakdance Element Studio zapisuje elementy do `elements/`, makrá do `macros/` a presety do `presets/`. Vydanie vytvoríš spustením `build-release.ps1` z priečinka projektu. Skript automaticky zvýši minor verziu a nastaví patch na nulu v hlavnom PHP súbore aj `Stable tag` v tomto súbore; výsledný ZIP bude v `Releases/`.

Cieľ: Breakdance 2.8.3, WordPress 7.1.4, PHP 8.2.


== Changelog ==

= 1.0.0 =
- Základný plugin a Element Studio umiestnenia pre prvky, makrá a presety.
= 1.1.0 =
- Prvý hotový element Memories - Spomienky.
= 1.2.0 =
- Samostatná sekcia Elements by Miki v paneli prvkov.
- Memories - Spomienky prepracovaný: funkčné načítanie šablón a CSS, registrácia v Element Studio, ikona, karty s avatarom, štítkom, náklonom a páskou, opravená schéma dropdownu a responzívnych polí.
= 1.3.0 =
- Element sa volá Memories (sk: Spomienky); texty v editore sú po anglicky so slovenským prekladom v pluguine.
- Upozornenie po aktualizácii na novú hlavnú verziu Breakdance, dokumentácia aktualizácií.
= 1.31.0 =
- Nové elementy Google Calendar (Google kalendár) a Google Upcoming Events (Google najbližšie udalosti) nahrádzajú skripty z priečinka Script - Calendar.
= 1.33.0 =
- Nový element Toast (Oznámenie) nahrádza skript z priečinka Script - Toast.
