=== Breakdance Elements by Miki ===
Contributors: mikulaspolak
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: Proprietary - All rights reserved

Vlastné Breakdance prvky vytvorené cez Breakdance Element Studio.

== Inštalácia ==

1. Vo WordPresse otvor Pluginy -> Pridať nový plugin -> Nahrať plugin.
2. Nahraj ZIP vytvorený skriptom build-release.ps1 a plugin aktivuj.
3. Otvor stránku v Breakdance, obnov editor a z horného menu otvor Element Studio.
4. Vyber New element a ako umiestnenie zvoľ Miki Elements.
5. Element ukladaj do tohto pluginu. Nevyberaj priečinok Breakdance, pretože aktualizácia Breakdance môže jeho súbory prepísať.

== Prvý element: Memories - Spomienky ==

V Element Studio vytvor element s názvom Memories - Spomienky a nastav:

Content:
- Sekciu Spomienky s repeaterom `memories`.
- Repeater obsahuje `heading` (text), `quote` (viacriadkový text), `text` (viacriadkový text), `author` (text) a `image` (wpmedia, voliteľný).
- Nastav tlačidlo pridania položky na „Pridať spomienku“. Počet položiek obmedz na 1-99, ak to daná verzia Element Studio ponúka; pri vykreslení sa aj tak spracuje najviac 99 položiek.
- Sekciu Rozloženie s `columns_mode` (dropdown: automatic / manual), `min_card_width` (unit) a `columns` (number, 1-6, s Enable breakpoints).

Design:
- Medzera medzi kartami (`gap`, unit).
- Pozadie a vnútorné odsadenie karty.
- Zaoblenie obrázka/karty a jemný hover posun.

HTML a CSS:
- Vykresli karty ako semantic `article` prvky. Citát zobraz ako samostatný zvýraznený blok pred odsekom.
- Obrázok vynechaj, ak nie je nastavený; jeho alternatívny text nastav podľa názvu spomienky alebo autora.
- Pre masonry použi viacstĺpcové CSS (`column-count`/`column-width`) a `break-inside: avoid`, aby karty zostali celé. Poradie naprieč stĺpcami môže byť prirodzené masonry poradie.
- Režim automatic použije `column-width` z `min_card_width`; režim manual použije responzívnu hodnotu `columns`.
- Pri responzívnych hodnotách Breakdance generuje CSS pre svoje breakpointy. Do CSS šablóny preto nepridávaj vlastné media queries.
- Hover animácia má byť nenápadná a rešpektovať `prefers-reduced-motion`.

Po uložení sa súbory elementu vytvoria v `elements/Memories_Spomienky/`. Skontroluj element na desktope, tablete a mobile v editore aj na publikovanej stránke.

== Vývoj a vydanie ==

Breakdance Element Studio zapisuje elementy do `elements/`, makrá do `macros/` a presety do `presets/`. Tieto súbory patria do tohto repozitára. Pred zmenami v Element Studio urob commit alebo zálohu; tlačidlo Delete v Studiu súbory odstráni.

Vydanie pluginu vytvoríš spustením `build-release.ps1` z priečinka projektu. Výsledný ZIP bude v `Releases/`.

Testované pre Breakdance 2.8.3 a PHP 8.2.

== Changelog ==

= 1.0.0 =
- Základný plugin a Element Studio umiestnenia pre prvky, makrá a presety.