(function () {
  const mobileQuery = window.matchMedia('(max-width: 767px)');
  const reducedMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  const scrollFrames = new WeakMap();
  const layoutAnimations = new WeakMap();
  const expandedClass = 'miki-memories__card--expanded';

  function setExpanded(card, expanded) {
    const button = card.querySelector('.miki-memories__toggle');
    const body = card.querySelector('.miki-memories__body');
    const icon = button?.querySelector('.miki-memories__toggle-icon');

    card.classList.toggle(expandedClass, expanded);

    if (button) {
      button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      const label = expanded ? button.dataset.closeLabel : button.dataset.openLabel;

      if (label) {
        button.setAttribute('aria-label', label);
      }
    }

    if (icon) {
      icon.textContent = expanded ? '−' : '+';
    }

    if (body) {
      if (mobileQuery.matches) {
        body.setAttribute('aria-hidden', expanded ? 'false' : 'true');
        body.inert = !expanded;
      } else {
        body.removeAttribute('aria-hidden');
        body.inert = false;
      }
    }
  }

  function cancelPendingScroll(grid) {
    const frame = scrollFrames.get(grid);

    if (frame !== undefined) {
      cancelAnimationFrame(frame);
      scrollFrames.delete(grid);
    }
  }

  function cancelLayoutAnimations(grid) {
    grid.querySelectorAll('[data-miki-memory-card]').forEach((card) => {
      const animation = layoutAnimations.get(card);

      if (animation) {
        animation.cancel();
        layoutAnimations.delete(card);
      }
    });
  }

  function capturePositions(grid) {
    return new Map(
      [...grid.querySelectorAll('[data-miki-memory-card]')].map((card) => [
        card,
        card.getBoundingClientRect(),
      ])
    );
  }

  function animateReflow(positions) {
    if (reducedMotionQuery.matches || typeof Element.prototype.animate !== 'function') {
      return;
    }

    positions.forEach((previousRect, card) => {
      const nextRect = card.getBoundingClientRect();
      const x = previousRect.left - nextRect.left;
      const y = previousRect.top - nextRect.top;
      const wasVisible = previousRect.bottom > 0 && previousRect.top < window.innerHeight;
      const isVisible = nextRect.bottom > 0 && nextRect.top < window.innerHeight;

      if ((!wasVisible && !isVisible) || (Math.abs(x) < 1 && Math.abs(y) < 1)) {
        return;
      }

      const transform = getComputedStyle(card).transform;
      const baseTransform = transform === 'none' ? '' : transform;
      const animation = card.animate(
        [
          { transform: `translate(${x}px, ${y}px) ${baseTransform}`.trim() },
          { transform: baseTransform || 'none' },
        ],
        {
          duration: 620,
          easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
        }
      );

      layoutAnimations.set(card, animation);
      animation.onfinish = () => {
        if (layoutAnimations.get(card) === animation) {
          layoutAnimations.delete(card);
        }
      };
      animation.oncancel = () => {
        if (layoutAnimations.get(card) === animation) {
          layoutAnimations.delete(card);
        }
      };
    });
  }

  function focusAndScroll(grid, card) {
    const heading = card.querySelector('.miki-memories__heading');

    if (heading) {
      heading.focus({ preventScroll: true });
    } else {
      card.setAttribute('tabindex', '-1');
      card.focus({ preventScroll: true });
    }

    cancelPendingScroll(grid);
    const scrollTarget = heading || card;
    const frame = requestAnimationFrame(() => {
      scrollFrames.delete(grid);

      if (!card.classList.contains(expandedClass)) {
        return;
      }

      const bounds = scrollTarget.getBoundingClientRect();

      if (bounds.top < 0 || bounds.bottom > window.innerHeight) {
        scrollTarget.scrollIntoView({
          behavior: reducedMotionQuery.matches ? 'auto' : 'smooth',
          block: 'nearest',
        });
      }
    });

    scrollFrames.set(grid, frame);
  }

  function syncResponsiveState() {
    document.querySelectorAll('[data-miki-memories]').forEach((grid) => {
      cancelPendingScroll(grid);
      cancelLayoutAnimations(grid);
      grid.querySelectorAll('[data-miki-memory-card]').forEach((card) => {
        setExpanded(card, false);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncResponsiveState, { once: true });
  } else {
    syncResponsiveState();
  }

  window.addEventListener('pageshow', syncResponsiveState);
  if (typeof mobileQuery.addEventListener === 'function') {
    mobileQuery.addEventListener('change', syncResponsiveState);
  } else {
    mobileQuery.addListener(syncResponsiveState);
  }

  document.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target : event.target.parentElement;
    const button = target?.closest('.miki-memories__toggle');

    if (!button || !mobileQuery.matches) {
      return;
    }

    const grid = button.closest('[data-miki-memories]');
    const card = button.closest('[data-miki-memory-card]');

    if (!grid || !card) {
      return;
    }

    cancelPendingScroll(grid);
    const positions = capturePositions(grid);
    cancelLayoutAnimations(grid);
    const wasExpanded = card.classList.contains(expandedClass);

    grid.querySelectorAll(`.${expandedClass}`).forEach((expandedCard) => {
      setExpanded(expandedCard, false);
    });

    if (!wasExpanded) {
      setExpanded(card, true);
    }

    animateReflow(positions);

    if (!wasExpanded) {
      focusAndScroll(grid, card);
    }
  });
})();
