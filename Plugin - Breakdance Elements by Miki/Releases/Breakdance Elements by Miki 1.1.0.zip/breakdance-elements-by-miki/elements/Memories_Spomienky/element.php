<?php

namespace BreakdanceElementsByMiki;

use Breakdance\Elements\Element;
use function Breakdance\Elements\c;

class MemoriesSpomienky extends Element
{
    public static function name()
    {
        return 'Memories - Spomienky';
    }

    public static function slug()
    {
        return __CLASS__;
    }

    public static function className()
    {
        return 'bde-miki-memories';
    }

    public static function category()
    {
        return 'basic';
    }

    public static function tag()
    {
        return 'div';
    }

    public static function tagOptions()
    {
        return ['div', 'section'];
    }

    public static function contentControls()
    {
        return [
            c(
                'memories',
                'Spomienky',
                [
                    c(
                        'items',
                        'Karty',
                        [
                            c('heading', 'Nadpis', [], ['type' => 'text', 'layout' => 'vertical'], false, false),
                            c('quote', 'Citát', [], ['type' => 'text', 'layout' => 'vertical', 'textOptions' => ['multiline' => true]], false, false),
                            c('text', 'Odsek', [], ['type' => 'text', 'layout' => 'vertical', 'textOptions' => ['multiline' => true]], false, false),
                            c('author', 'Autor', [], ['type' => 'text', 'layout' => 'vertical'], false, false),
                            c('image', 'Obrázok', [], ['type' => 'wpmedia'], false, false),
                        ],
                        ['type' => 'repeater'],
                        false,
                        false
                    ),
                ],
                ['type' => 'section', 'layout' => 'vertical'],
                false,
                false
            ),
        ];
    }

    public static function designControls()
    {
        return [
            c(
                'layout',
                'Rozloženie',
                [
                    c(
                        'columns_mode',
                        'Režim stĺpcov',
                        [],
                        [
                            'type' => 'dropdown',
                            'dropdownOptions' => [
                                'items' => [
                                    ['text' => 'Automaticky', 'value' => 'auto'],
                                    ['text' => 'Manuálne', 'value' => 'manual'],
                                ],
                            ],
                        ],
                        false,
                        false
                    ),
                    c('minimum_card_width', 'Minimálna šírka karty', [], ['type' => 'unit'], true, false),
                    c('columns', 'Počet stĺpcov', [], ['type' => 'number'], true, false),
                    c('gap', 'Medzera medzi kartami', [], ['type' => 'unit'], true, false),
                ],
                ['type' => 'section', 'layout' => 'vertical'],
                false,
                false
            ),
        ];
    }

    public static function defaultProperties()
    {
        return [
            'content' => [
                'memories' => [
                    'items' => [],
                ],
            ],
            'design' => [
                'layout' => [
                    'columns_mode' => 'auto',
                    'columns' => 3,
                ],
            ],
        ];
    }
}