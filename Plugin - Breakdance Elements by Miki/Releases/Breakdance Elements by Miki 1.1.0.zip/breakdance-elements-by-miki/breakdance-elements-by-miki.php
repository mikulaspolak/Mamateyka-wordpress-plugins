<?php

/**
 * Plugin Name: Breakdance Elements by Miki
 * Description: Custom Breakdance elements, macros, and presets by Miki.
 * Version: 1.1.0
 * Author: Mikulas Polak
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: Proprietary - All rights reserved
 */

namespace BreakdanceElementsByMiki;

if (!defined('ABSPATH')) {
    exit;
}

use function Breakdance\Util\getDirectoryPathRelativeToPluginFolder;

add_action('breakdance_loaded', function () {
    $pluginPath = getDirectoryPathRelativeToPluginFolder(__DIR__);

    \Breakdance\ElementStudio\registerSaveLocation(
        $pluginPath . '/elements',
        'BreakdanceElementsByMiki',
        'element',
        'Miki Elements',
        false
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        $pluginPath . '/macros',
        'BreakdanceElementsByMiki',
        'macro',
        'Miki Macros',
        false
    );

    \Breakdance\ElementStudio\registerSaveLocation(
        $pluginPath . '/presets',
        'BreakdanceElementsByMiki',
        'preset',
        'Miki Presets',
        false
    );
}, 9);
