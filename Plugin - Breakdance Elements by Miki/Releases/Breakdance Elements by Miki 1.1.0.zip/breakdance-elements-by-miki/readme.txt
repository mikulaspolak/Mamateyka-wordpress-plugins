=== Breakdance Elements by Miki ===
Contributors: mikulaspolak
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.0
License: Proprietary - All rights reserved

Vlastné Breakdance prvky vytvorené cez Breakdance Element Studio.

== Inštalácia ==

1. Vo WordPresse otvor Pluginy -> Pridať nový plugin -> Nahrať plugin.
2. Nahraj ZIP vytvorený skriptom build-release.ps1 a plugin aktivuj.
3. Otvor stránku v Breakdance, obnov editor a z horného menu otvor Element Studio.
4. Vyber New element a ako umiestnenie zvoľ Miki Elements.
5. Element ukladaj do tohto pluginu. Nevyberaj priečinok Breakdance, pretože aktualizácia Breakdance môže jeho súbory prepísať.

== Element: Memories - Spomienky ==

Element je súčasťou pluginu a zobrazí sa v Breakdance paneli prvkov pod kategóriou Basic.

- Repeater spomienok: nadpis, zvýraznený citát, odsek, autor a voliteľný obrázok.
- Vykreslí najviac 99 kariet; bez obrázka sa obrázkový blok nezobrazí.
- Masonry rozloženie používa CSS columns. Poradie položiek pokračuje zhora nadol v jednotlivých stĺpcoch.
- Režim stĺpcov je automatický alebo manuálny. Manuálny počet aj minimálna šírka pre automatický režim podporujú Breakdance breakpointy.
- Karty majú jemný hover efekt bez JavaScriptu a rešpektujú `prefers-reduced-motion`.

Po aktivácii pluginu vlož element „Memories - Spomienky“ z panelu prvkov a pridaj spomienky v jeho Content nastaveniach. Skontroluj rozloženie na desktope, tablete a mobile.

== Vývoj a vydanie ==

Breakdance Element Studio zapisuje elementy do `elements/`, makrá do `macros/` a presety do `presets/`. Tieto súbory patria do tohto repozitára. Pred zmenami v Element Studio urob commit alebo zálohu; tlačidlo Delete v Studiu súbory odstráni.

Vydanie pluginu vytvoríš spustením `build-release.ps1` z priečinka projektu. Výsledný ZIP bude v `Releases/`.

Testované pre Breakdance 2.8.3 a PHP 8.2.

== Changelog ==

= 1.0.0 =
- Základný plugin a Element Studio umiestnenia pre prvky, makrá a presety.
= 1.1.0 =
- Prvý hotový element Memories - Spomienky.